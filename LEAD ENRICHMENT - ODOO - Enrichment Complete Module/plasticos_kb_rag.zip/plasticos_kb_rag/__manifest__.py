{
    "name": "PlastOS KB RAG — Knowledge Base Retrieval-Augmented Generation",
    "version": "19.0.1.0.0",
    "category": "PlastOS/Knowledge",
    "summary": "TF-IDF chunk search over polymer KB data for match enrichment",
    "description": """
        Standalone RAG service for the PlastOS buyer match pipeline.

        - Chunks structured KB records into searchable text paragraphs
        - Builds augmented TF term vectors stored in PostgreSQL (zero ext deps)
        - Cosine similarity search callable by any module
        - Post-match enrichment on plasticos.match.result records
        - Deterministic fallback when no AI service is available
        - Nightly cron to rebuild chunks from polymer KB data

        Data source:  plasticos.polymer.kb  (from plasticos_polymer_kb module)
        Output target: plasticos.match.result (from plasticos_buyer_match_engine)
        AI service:    Optional — works fully without one
    """,
    "author": "PlastOS Dev",
    "license": "LGPL-3",
    "depends": [
        "plasticos_polymer_kb",
        "plasticos_buyer_match_engine",
        "mail",
    ],
    "data": [
        "security/ir.model.access.csv",
        "views/kb_chunk_views.xml",
        "views/match_result_rag_views.xml",
        "data/rag_cron.xml",
    ],
    "installable": True,
    "application": False,
    "auto_install": False,
}
