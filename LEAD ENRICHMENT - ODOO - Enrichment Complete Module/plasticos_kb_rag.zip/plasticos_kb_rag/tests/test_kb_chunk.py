# -*- coding: utf-8 -*-
"""Unit tests for plasticos.kb.chunk — TF-IDF engine + similarity search."""
from odoo.tests.common import TransactionCase


class TestKBChunk(TransactionCase):
    """Test TF-IDF tokenization, vectorization, and cosine search."""

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Chunk = cls.env["plasticos.kb.chunk"]

    def test_tokenize_basic(self):
        """Tokenizer lowercases and preserves decimals."""
        tokens = self.Chunk._tokenize("HDPE density 0.930-0.970 g/cm³")
        self.assertIn("hdpe", tokens)
        self.assertIn("density", tokens)
        self.assertIn("g", tokens)
        # Decimals should be preserved as single tokens
        self.assertTrue(any("0" in t for t in tokens))

    def test_tokenize_empty(self):
        self.assertEqual(self.Chunk._tokenize(""), [])
        self.assertEqual(self.Chunk._tokenize(None), [])

    def test_l2_norm_basic(self):
        norm = self.Chunk._l2_norm({"a": 3.0, "b": 4.0})
        self.assertAlmostEqual(norm, 5.0, places=4)

    def test_l2_norm_empty(self):
        self.assertEqual(self.Chunk._l2_norm({}), 1e-9)

    def test_build_term_vector(self):
        """Build TF vector and verify augmented formula."""
        chunk = self.Chunk.create({
            "source_key": "test_kb",
            "chunk_text": "HDPE HDPE density",
        })
        chunk._build_term_vector()
        self.assertTrue(chunk.term_vector)
        self.assertGreater(chunk.doc_norm, 0)

        import json
        vec = json.loads(chunk.term_vector)
        # 'hdpe' appears 2x (max), so tf = 0.5 + 0.5*1.0 = 1.0
        self.assertAlmostEqual(vec.get("hdpe", 0), 1.0, places=2)
        # 'density' appears 1x, max=2, so tf = 0.5 + 0.5*0.5 = 0.75
        self.assertAlmostEqual(vec.get("density", 0), 0.75, places=2)

    def test_similarity_search_empty_query(self):
        result = self.Chunk.similarity_search("", polymer_type=None)
        self.assertEqual(result, [])

    def test_similarity_search_no_chunks(self):
        result = self.Chunk.similarity_search("HDPE density")
        self.assertEqual(result, [])

    def test_similarity_search_match(self):
        """Create chunks, verify cosine ranking."""
        c1 = self.Chunk.create({
            "source_key": "hdpe_kb",
            "polymer_type": "HDPE",
            "section": "density_specs",
            "chunk_text": "HDPE density range 0.941 to 0.965 g/cm3 "
                          "high density polyethylene specifications",
        })
        c2 = self.Chunk.create({
            "source_key": "pp_kb",
            "polymer_type": "PP",
            "section": "contamination",
            "chunk_text": "PP polypropylene contamination limits "
                          "PVC threshold 500 ppm maximum",
        })
        c3 = self.Chunk.create({
            "source_key": "hdpe_kb",
            "polymer_type": "HDPE",
            "section": "melt_index",
            "chunk_text": "HDPE melt flow index 0.3 to 25 g/10min "
                          "extrusion blow molding injection",
        })
        for c in [c1, c2, c3]:
            c._build_term_vector()

        results = self.Chunk.similarity_search(
            "HDPE density specifications",
            polymer_type="HDPE",
            top_k=5,
        )
        self.assertTrue(len(results) >= 1)
        self.assertEqual(results[0]["polymer_type"], "HDPE")
        self.assertGreater(results[0]["score"], 0.3)
        # Density chunk should rank higher than melt index
        self.assertEqual(results[0]["section"], "density_specs")

    def test_similarity_search_polymer_filter(self):
        """Polymer filter excludes non-matching chunks."""
        c1 = self.Chunk.create({
            "source_key": "pp_kb",
            "polymer_type": "PP",
            "section": "overview",
            "chunk_text": "PP polypropylene high quality recycled material",
        })
        c1._build_term_vector()

        results = self.Chunk.similarity_search(
            "polypropylene", polymer_type="HDPE", top_k=5
        )
        # PP chunk should NOT appear when filtering for HDPE
        pp_results = [r for r in results if r["polymer_type"] == "PP"]
        self.assertEqual(len(pp_results), 0)
