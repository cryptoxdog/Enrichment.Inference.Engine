# -*- coding: utf-8 -*-
"""Unit tests for match.result RAG enrichment."""
from odoo.tests.common import TransactionCase


class TestMatchResultRAG(TransactionCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        cls.Chunk = cls.env["plasticos.kb.chunk"]
        cls.MatchResult = cls.env["plasticos.match.result"]

    def test_rag_fields_exist(self):
        """RAG fields are added to match.result via _inherit."""
        fields_list = self.MatchResult.fields_get()
        for fname in [
            "rag_context", "rag_insight", "rag_enrichment_date",
            "rag_chunk_count", "rag_top_score",
        ]:
            self.assertIn(fname, fields_list,
                          f"Field {fname} missing from match.result")

    def test_fallback_summary(self):
        """Fallback summary generates readable text without AI."""
        chunks = [
            {
                "id": 1,
                "chunk_text": "HDPE density 0.941 specifications",
                "section": "density_specs",
                "source_key": "hdpe_kb",
                "polymer_type": "HDPE",
                "score": 0.87,
            },
        ]
        # Create a minimal match.result to test fallback
        partner = self.env["res.partner"].create({"name": "Test Buyer"})
        # We need an intake — if not available, just test the method exists
        if "plasticos.intake" in self.env:
            intake = self.env["plasticos.intake"].create({"name": "TEST-001"})
            result = self.MatchResult.create({
                "intake_id": intake.id,
                "buyer_partner_id": partner.id,
                "score": 85.0,
                "state": "pending",
            })
            summary = result._rag_fallback_summary(chunks)
            self.assertIn("KB Reference Summary", summary)
            self.assertIn("density_specs", summary)
            self.assertIn("87%", summary)
        else:
            # Just verify the method signature exists
            self.assertTrue(
                hasattr(self.MatchResult, "_rag_fallback_summary")
            )
