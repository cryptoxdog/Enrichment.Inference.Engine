# -*- coding: utf-8 -*-
"""Unit tests for KB RAG builder — section extraction + chunking."""
from odoo.tests.common import TransactionCase


class TestRAGBuilder(TransactionCase):

    def test_split_chunk_short(self):
        """Text under max_chars returns single chunk."""
        from odoo.addons.plasticos_kb_rag.models.kb_rag_builder import (
            PolymerKBRAGBuilder,
        )
        result = PolymerKBRAGBuilder._split_chunk(
            "Short text under limit", max_chars=800
        )
        self.assertEqual(len(result), 1)

    def test_split_chunk_long(self):
        """Text over max_chars splits on paragraph boundaries."""
        from odoo.addons.plasticos_kb_rag.models.kb_rag_builder import (
            PolymerKBRAGBuilder,
        )
        text = ("A" * 400 + "\n\n" + "B" * 400 + "\n\n" + "C" * 400)
        result = PolymerKBRAGBuilder._split_chunk(text, max_chars=500)
        self.assertTrue(len(result) >= 2)
        for chunk in result:
            self.assertTrue(len(chunk) <= 500)
