# -*- coding: utf-8 -*-
"""PlastOS KB RAG Builder — Converts polymer KB records to searchable chunks.

Reads from plasticos.polymer.kb (structured models) and produces
plasticos.kb.chunk records with TF-IDF vectors.  This is the bridge
between our typed KB and the RAG text-search layer.

Source:  plasticos.polymer.kb  (grades, tiers, rules, buyer profiles)
Output:  plasticos.kb.chunk    (flat text with TF vectors)
"""
import json
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class PolymerKBRAGBuilder(models.Model):
    """Extends plasticos.polymer.kb with RAG chunk-building capabilities."""

    _inherit = "plasticos.polymer.kb"

    chunk_ids = fields.One2many(
        "plasticos.kb.chunk",
        "kb_record_id",
        string="RAG Chunks",
        help="Text chunks generated from this KB record for RAG retrieval",
    )
    chunk_count = fields.Integer(
        string="Chunk Count",
        compute="_compute_chunk_count",
        store=True,
    )
    last_chunk_build = fields.Datetime(
        string="Last Chunk Build",
        help="When RAG chunks were last rebuilt from this KB record",
    )

    @api.depends("chunk_ids")
    def _compute_chunk_count(self):
        for rec in self:
            rec.chunk_count = len(rec.chunk_ids)

    # ── Button action: Build chunks for this KB record ──────────────────

    def action_build_chunks(self):
        """Convert this polymer KB record into searchable RAG chunks.

        Pipeline:
          1. Delete existing chunks for this record
          2. Extract text from all related sub-models
          3. Split into ~800-char paragraphs
          4. Create kb.chunk records with TF vectors
          5. Post count to chatter
        """
        Chunk = self.env["plasticos.kb.chunk"]
        total_created = 0

        for rec in self:
            # Step 1: Clear existing chunks
            rec.chunk_ids.unlink()

            # Step 2: Extract sections from the KB record + sub-models
            sections = rec._extract_kb_sections()
            if not sections:
                _logger.info(
                    "KB RAG Builder: No content to chunk for %s", rec.name
                )
                continue

            # Step 3-4: Chunk and create
            seq = 0
            for section_label, text in sections:
                if not text or len(text.strip()) < 20:
                    continue
                sub_chunks = self._split_chunk(text, max_chars=800)
                for chunk_text in sub_chunks:
                    if len(chunk_text.strip()) < 20:
                        continue
                    chunk = Chunk.create({
                        "source_key": rec.name or f"kb_{rec.id}",
                        "polymer_type": rec.polymer_type or None,
                        "section": section_label,
                        "sequence": seq,
                        "chunk_text": chunk_text.strip(),
                        "kb_record_id": rec.id,
                    })
                    chunk._build_term_vector()
                    seq += 1
                    total_created += 1

            # Step 5: Audit trail
            rec.last_chunk_build = fields.Datetime.now()
            if hasattr(rec, "message_post"):
                rec.message_post(
                    body=(
                        f"🧩 RAG Chunks Built: {seq} chunks created "
                        f"from {len(sections)} sections"
                    ),
                    subtype_xmlid="mail.mt_note",
                )

        # Return notification
        return {
            "type": "ir.actions.client",
            "tag": "display_notification",
            "params": {
                "title": "RAG Chunks Built",
                "message": f"{total_created} chunks created and vectorized.",
                "sticky": False,
                "type": "success",
            },
        }

    # ── Cron: Rebuild all chunks ────────────────────────────────────────

    @api.model
    def action_build_all_chunks(self):
        """Build RAG chunks from ALL active polymer KB records.

        Callable from ir.cron for nightly rebuilds.
        """
        all_kbs = self.search([("active", "=", True)])
        _logger.info(
            "KB RAG Builder: Rebuilding chunks for %d KB records",
            len(all_kbs),
        )
        all_kbs.action_build_chunks()

    # ── Section extraction from structured KB models ────────────────────

    def _extract_kb_sections(self):
        """Extract text sections from this KB record and all sub-models.

        Returns list of (section_label, text_content) tuples.
        Each section becomes one or more chunks after splitting.
        """
        self.ensure_one()
        sections = []

        # Master record overview
        overview_parts = []
        if self.polymer_type:
            overview_parts.append(f"Polymer: {self.polymer_type}")
        if self.name:
            overview_parts.append(f"KB Entry: {self.name}")
        if hasattr(self, "description") and self.description:
            overview_parts.append(self.description)
        if hasattr(self, "notes") and self.notes:
            overview_parts.append(self.notes)
        if overview_parts:
            sections.append(("overview", "\n".join(overview_parts)))

        # Grade records
        if hasattr(self, "grade_ids") and self.grade_ids:
            grade_texts = []
            for g in self.grade_ids:
                parts = [f"Grade: {g.name or g.code or 'unnamed'}"]
                for attr in [
                    "mi_min", "mi_max", "density_min", "density_max",
                    "tensile_min", "tensile_max", "flexural_min",
                    "flexural_max", "izod_min", "izod_max",
                    "hdt_min", "hdt_max", "vicat_min", "vicat_max",
                    "hardness_min", "hardness_max",
                    "application_class", "process_fit",
                ]:
                    val = getattr(g, attr, None)
                    if val:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                if hasattr(g, "notes") and g.notes:
                    parts.append(f"  Notes: {g.notes}")
                grade_texts.append("\n".join(parts))
            if grade_texts:
                sections.append(
                    ("grade_specifications", "\n\n".join(grade_texts))
                )

        # Quality tier records
        if hasattr(self, "tier_ids") and self.tier_ids:
            tier_texts = []
            for t in self.tier_ids:
                parts = [f"Quality Tier {getattr(t, 'tier_level', '?')}: "
                         f"{t.name or ''}"]
                for attr in [
                    "contamination_max_pct", "moisture_max_pct",
                    "color_consistency", "odor_acceptable",
                    "pvc_max_ppm", "metal_max_ppm",
                    "fines_max_pct", "label_max_pct",
                    "price_modifier",
                ]:
                    val = getattr(t, attr, None)
                    if val is not None:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                if hasattr(t, "notes") and t.notes:
                    parts.append(f"  Notes: {t.notes}")
                tier_texts.append("\n".join(parts))
            if tier_texts:
                sections.append(
                    ("quality_tiers", "\n\n".join(tier_texts))
                )

        # Contamination rules
        if hasattr(self, "rule_ids") and self.rule_ids:
            rule_texts = []
            for r in self.rule_ids:
                parts = [
                    f"Rule: {r.name or getattr(r, 'contaminant_type', '')}",
                ]
                for attr in [
                    "contaminant_type", "threshold_pct", "threshold_ppm",
                    "action", "severity", "gate_behavior",
                    "detection_method",
                ]:
                    val = getattr(r, attr, None)
                    if val is not None:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                if hasattr(r, "notes") and r.notes:
                    parts.append(f"  Notes: {r.notes}")
                rule_texts.append("\n".join(parts))
            if rule_texts:
                sections.append(
                    ("contamination_rules", "\n\n".join(rule_texts))
                )

        # Process fit records
        if hasattr(self, "process_fit_ids") and self.process_fit_ids:
            fit_texts = []
            for pf in self.process_fit_ids:
                parts = [
                    f"Process: {getattr(pf, 'process_type', '')} — "
                    f"{pf.name or ''}",
                ]
                for attr in [
                    "mi_range_min", "mi_range_max",
                    "density_range_min", "density_range_max",
                    "suitability", "notes",
                ]:
                    val = getattr(pf, attr, None)
                    if val:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                fit_texts.append("\n".join(parts))
            if fit_texts:
                sections.append(
                    ("process_fit", "\n\n".join(fit_texts))
                )

        # Buyer profile / archetype records
        if hasattr(self, "buyer_profile_ids") and self.buyer_profile_ids:
            bp_texts = []
            for bp in self.buyer_profile_ids:
                parts = [
                    f"Buyer Archetype: "
                    f"{getattr(bp, 'archetype_code', '')} — "
                    f"{bp.name or ''}",
                ]
                for attr in [
                    "archetype_code", "typical_polymer_use",
                    "min_quality_tier", "preferred_forms",
                    "price_sensitivity", "volume_preference",
                    "certifications_required", "key_concerns",
                    "talking_points", "notes",
                ]:
                    val = getattr(bp, attr, None)
                    if val:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                bp_texts.append("\n".join(parts))
            if bp_texts:
                sections.append(
                    ("buyer_profiles", "\n\n".join(bp_texts))
                )

        # Pricing records
        if hasattr(self, "pricing_ids") and self.pricing_ids:
            price_texts = []
            for pr in self.pricing_ids:
                parts = [f"Pricing: {pr.name or ''}"]
                for attr in [
                    "grade_ref", "quality_tier",
                    "price_low", "price_high", "price_unit",
                    "market_segment", "notes",
                ]:
                    val = getattr(pr, attr, None)
                    if val:
                        label = attr.replace("_", " ").title()
                        parts.append(f"  {label}: {val}")
                price_texts.append("\n".join(parts))
            if price_texts:
                sections.append(
                    ("pricing_data", "\n\n".join(price_texts))
                )

        return sections

    # ── Chunk splitting ─────────────────────────────────────────────────

    @staticmethod
    def _split_chunk(text, max_chars=800):
        """Split text into chunks of roughly max_chars on paragraph boundaries.

        Splits on double newlines first; if a paragraph exceeds max_chars
        it gets split on single newlines, then hard-wrapped as last resort.
        Returns list[str].
        """
        if not text or len(text) <= max_chars:
            return [text] if text else []

        paragraphs = text.split("\n\n")
        chunks = []
        current = ""

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue
            if len(current) + len(para) + 2 <= max_chars:
                current = f"{current}\n\n{para}" if current else para
            else:
                if current:
                    chunks.append(current)
                if len(para) <= max_chars:
                    current = para
                else:
                    # Hard split oversized paragraph
                    lines = para.split("\n")
                    current = ""
                    for line in lines:
                        if len(current) + len(line) + 1 <= max_chars:
                            current = f"{current}\n{line}" if current else line
                        else:
                            if current:
                                chunks.append(current)
                            current = line[:max_chars]

        if current:
            chunks.append(current)

        return [c for c in chunks if len(c.strip()) >= 20]
