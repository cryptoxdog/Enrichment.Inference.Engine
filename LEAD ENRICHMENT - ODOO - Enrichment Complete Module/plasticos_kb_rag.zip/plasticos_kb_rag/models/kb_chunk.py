# -*- coding: utf-8 -*-
"""PlastOS KB Chunk — TF-IDF text chunks for RAG retrieval.

Stores pre-chunked KB text with augmented term-frequency vectors.
Similarity search runs entirely in Python/PostgreSQL — zero external
vector DB, zero pip dependencies.

Callable by ANY module:
    chunks = env['plasticos.kb.chunk'].similarity_search(
        query_text="HDPE density contamination",
        polymer_type="HDPE",
        top_k=5,
    )
"""
import json
import logging
import math
import re
from collections import Counter

from odoo import api, fields, models

_logger = logging.getLogger(__name__)

# Canonical polymer codes — shared across PlastOS KB ecosystem
POLYMER_TYPES = [
    "HDPE", "LDPE", "LLDPE", "PP", "PET", "PVC", "PS",
    "ABS", "PC", "PA", "HIPS", "TPE", "TPU", "EVA",
    "POM", "PMMA", "PBT", "PPO",
]


class KBChunk(models.Model):
    _name = "plasticos.kb.chunk"
    _description = "PlastOS KB Chunk — RAG Retrieval Unit"
    _order = "polymer_type, source_key, sequence"

    # ── Fields ──────────────────────────────────────────────────────────
    source_key = fields.Char(
        string="Source Key",
        required=True,
        index=True,
        help="Origin identifier, e.g. polymer KB record name or YAML key",
    )
    polymer_type = fields.Char(
        string="Polymer Type",
        index=True,
        help="HDPE, PP, PET, etc. NULL = cross-polymer / generic",
    )
    section = fields.Char(
        string="Section Label",
        help="e.g. density_specs, contamination, process_fit, buyer_profiles",
    )
    sequence = fields.Integer(
        string="Chunk Sequence",
        default=0,
        help="Ordering within a source_key",
    )
    chunk_text = fields.Text(
        string="Chunk Text",
        required=True,
        help="The actual KB content for this chunk (~200-800 chars)",
    )
    term_vector = fields.Text(
        string="Term Vector (JSON)",
        help="JSON dict of term → TF weight, built by _build_term_vector()",
    )
    doc_norm = fields.Float(
        string="Document L2 Norm",
        digits=(12, 6),
        default=0.0,
        help="Pre-computed L2 norm of term_vector for fast cosine calc",
    )
    kb_record_id = fields.Many2one(
        "plasticos.polymer.kb",
        string="Source KB Record",
        ondelete="cascade",
        help="Link back to the structured KB record this chunk came from",
    )

    # ── Static helpers ──────────────────────────────────────────────────

    @staticmethod
    def _tokenize(text):
        """Lowercase, strip punctuation, split on whitespace.

        Preserves decimal numbers (e.g. '0.930' stays as one token).
        Returns list[str].
        """
        if not text:
            return []
        return re.findall(r'[a-z0-9]+(?:\.[0-9]+)?', text.lower())

    @staticmethod
    def _l2_norm(vec_dict):
        """Compute L2 (Euclidean) norm of a term vector dict.

        Returns 1e-9 minimum to prevent division by zero.
        """
        if not vec_dict:
            return 1e-9
        return math.sqrt(sum(v * v for v in vec_dict.values())) or 1e-9

    # ── Instance methods ────────────────────────────────────────────────

    def _build_term_vector(self):
        """Build augmented TF vector and store as JSON.

        Formula: tf(t) = 0.5 + 0.5 * (raw_count(t) / max_raw_count)
        Augmented TF prevents bias toward very long documents.
        No IDF — in domain-specific KB, common terms ARE the signal.
        """
        for rec in self:
            tokens = self._tokenize(rec.chunk_text)
            if not tokens:
                rec.term_vector = "{}"
                rec.doc_norm = 0.0
                continue
            counts = Counter(tokens)
            max_count = max(counts.values())
            tf_vector = {
                term: 0.5 + 0.5 * (count / max_count)
                for term, count in counts.items()
            }
            norm = self._l2_norm(tf_vector)
            rec.term_vector = json.dumps(tf_vector)
            rec.doc_norm = norm

    # ── Public API: similarity_search ───────────────────────────────────

    @api.model
    def similarity_search(self, query_text, polymer_type=None, top_k=5):
        """Return top-K chunks most similar to query_text.

        Uses cosine similarity on augmented TF vectors.
        Callable by any module — no AI dependency.

        :param query_text: Free-text query string.
        :param polymer_type: Optional polymer filter (e.g. 'HDPE').
        :param top_k: Number of chunks to return (default 5).
        :returns: list[dict] with keys: id, chunk_text, section,
                  source_key, polymer_type, score, kb_record_id.
        """
        if not query_text or not query_text.strip():
            return []

        # Build query TF vector
        q_tokens = self._tokenize(query_text)
        if not q_tokens:
            return []
        q_counts = Counter(q_tokens)
        q_max = max(q_counts.values())
        q_vector = {
            t: 0.5 + 0.5 * (c / q_max) for t, c in q_counts.items()
        }
        q_norm = self._l2_norm(q_vector)

        # Pre-filter candidates via ORM
        domain = [("term_vector", "!=", False), ("term_vector", "!=", "{}")]
        if polymer_type:
            domain = [
                "&",
                ("term_vector", "!=", False),
                ("term_vector", "!=", "{}"),
                "|",
                ("polymer_type", "=", polymer_type),
                ("polymer_type", "=", False),
            ]

        candidates = self.search(domain)
        if not candidates:
            return []

        # Score each candidate
        scored = []
        for chunk in candidates:
            try:
                d_vector = json.loads(chunk.term_vector or "{}")
            except (json.JSONDecodeError, TypeError):
                continue
            if not d_vector:
                continue

            # Cosine similarity: dot(q, d) / (|q| * |d|)
            dot_product = sum(
                q_vector.get(t, 0.0) * w for t, w in d_vector.items()
            )
            d_norm = chunk.doc_norm or self._l2_norm(d_vector)
            cosine = dot_product / (q_norm * d_norm)

            if cosine >= 0.01:
                scored.append({
                    "id": chunk.id,
                    "chunk_text": chunk.chunk_text,
                    "section": chunk.section or "",
                    "source_key": chunk.source_key or "",
                    "polymer_type": chunk.polymer_type or "",
                    "score": round(cosine, 4),
                    "kb_record_id": chunk.kb_record_id.id if chunk.kb_record_id else False,
                })

        # Sort descending by score, return top_k
        scored.sort(key=lambda x: x["score"], reverse=True)
        return scored[:top_k]
