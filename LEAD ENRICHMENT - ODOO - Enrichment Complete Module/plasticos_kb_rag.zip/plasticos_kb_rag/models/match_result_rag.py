# -*- coding: utf-8 -*-
"""PlastOS Match Result RAG — Post-match enrichment via KB retrieval.

Extends plasticos.match.result with RAG fields and an enrichment
action that retrieves relevant KB chunks, optionally calls an AI
service, and stores the insight on the match record.

Pipeline: match.result → build query → similarity_search → [AI] → store
"""
import json
import logging

from odoo import api, fields, models

_logger = logging.getLogger(__name__)


class MatchResultRAG(models.Model):
    """Extends match.result with RAG enrichment capabilities."""

    _inherit = "plasticos.match.result"

    # ── RAG enrichment fields (ADDITIVE ONLY) ───────────────────────────

    rag_context = fields.Text(
        string="RAG Context (JSON)",
        help="Top-K KB chunks used in last enrichment, as JSON array",
    )
    rag_insight = fields.Text(
        string="RAG Insight",
        help="AI-generated or fallback insight from RAG-augmented analysis",
    )
    rag_enrichment_date = fields.Datetime(
        string="RAG Enrichment Date",
        help="When RAG pipeline was last run on this record",
    )
    rag_chunk_count = fields.Integer(
        string="KB Chunks Retrieved",
        default=0,
        help="Number of chunks found in last similarity search",
    )
    rag_top_score = fields.Float(
        string="Top Chunk Similarity",
        digits=(5, 4),
        help="Highest cosine similarity score from last retrieval (0.0-1.0)",
    )

    # ── Button action: RAG Enrich ───────────────────────────────────────

    def action_rag_enrich(self):
        """Run RAG enrichment pipeline on match result record(s).

        Pipeline:
          1. Build retrieval query from match context
          2. similarity_search() on plasticos.kb.chunk
          3. Build RAG-augmented prompt (if AI service available)
          4. Call AI service OR generate deterministic fallback
          5. Store results + post to chatter
        """
        Chunk = self.env["plasticos.kb.chunk"]

        for rec in self:
            # ── Step 1: Build retrieval query from match context ─────
            query_parts = []

            # Polymer from intake → material_profile
            intake = rec.intake_id
            polymer = ""
            if intake and hasattr(intake, "material_profile_id"):
                mat = intake.material_profile_id
                if mat:
                    polymer = (
                        mat.polymer_id.code if hasattr(mat, "polymer_id")
                        and mat.polymer_id
                        else getattr(mat, "polymer", "")
                    ) or ""
                    if polymer:
                        query_parts.append(polymer)
                    for attr in [
                        "form", "color", "source_type",
                        "process_type", "material_source",
                    ]:
                        val = getattr(mat, attr, None)
                        if val:
                            query_parts.append(str(val))
                    # Contamination / quality signals
                    contam = getattr(mat, "contamination_pct", None)
                    if contam:
                        query_parts.append(f"contamination {contam}%")
                    density = getattr(mat, "density", None) or getattr(
                        mat, "specific_gravity", None
                    )
                    if density:
                        query_parts.append(f"density {density}")
                    mfi = getattr(mat, "melt_index", None) or getattr(
                        mat, "mfi", None
                    )
                    if mfi:
                        query_parts.append(f"melt index {mfi}")

            # Buyer facility context
            facility = rec.facility_profile_id
            if facility:
                proc = getattr(facility, "process_type", None)
                if proc:
                    query_parts.append(str(proc))
                if getattr(facility, "food_grade_certified", False):
                    query_parts.append("food grade")

            # Score context
            if rec.score:
                query_parts.append(f"match score {rec.score}")

            query_text = " ".join(query_parts) if query_parts else (
                "plastic recycling material matching"
            )

            # ── Step 2: Similarity search ───────────────────────────
            chunks = Chunk.similarity_search(
                query_text=query_text,
                polymer_type=polymer or None,
                top_k=5,
            )

            if not chunks:
                if hasattr(rec, "message_post"):
                    rec.message_post(
                        body=(
                            "⚠️ RAG Enrichment: No relevant KB chunks found. "
                            "Run <b>Build RAG Chunks</b> on polymer KB "
                            "records first."
                        ),
                        subtype_xmlid="mail.mt_note",
                    )
                continue

            # ── Step 3-4: AI service or deterministic fallback ──────
            insight = rec._rag_try_ai_enrich(chunks, polymer, query_text)
            if not insight:
                insight = rec._rag_fallback_summary(chunks)

            # ── Step 5: Store results ───────────────────────────────
            rec.write({
                "rag_context": json.dumps(chunks, indent=2),
                "rag_insight": insight,
                "rag_enrichment_date": fields.Datetime.now(),
                "rag_chunk_count": len(chunks),
                "rag_top_score": chunks[0]["score"] if chunks else 0.0,
            })

            # Chatter audit
            if hasattr(rec, "message_post"):
                source_keys = set(c.get("source_key", "") for c in chunks)
                rec.message_post(
                    body=(
                        f"🧠 <b>RAG Enrichment Complete</b><br/>"
                        f"Chunks Retrieved: {len(chunks)}<br/>"
                        f"Top Similarity: "
                        f"{chunks[0]['score']:.0%}<br/>"
                        f"Sources: {', '.join(source_keys)}<br/>"
                        f"<hr/>{insight}"
                    ),
                    subtype_xmlid="mail.mt_note",
                )

        return True

    # ── AI service integration (optional) ───────────────────────────────

    def _rag_try_ai_enrich(self, chunks, polymer, query_text):
        """Try to call AI service for synthesized insight.

        Returns AI response string, or None if no AI service available.
        Checks for plastic_ai.ai_service (Mack) first, then any
        configured AI endpoint.  Fully optional — never crashes.
        """
        self.ensure_one()
        try:
            if "plastic_ai.ai_service" not in self.env:
                return None
            ai_svc = self.env["plastic_ai.ai_service"].get_default_service()
            if not ai_svc:
                return None

            # Build prompt
            chunk_block = "\n\n".join(
                f"[KB:{c.get('source_key', '?')} / "
                f"{c.get('section', '?')}] "
                f"(relevance {c.get('score', 0):.0%})\n"
                f"{c.get('chunk_text', '')}"
                for c in chunks[:5]
            )

            buyer_name = ""
            if self.buyer_partner_id:
                buyer_name = self.buyer_partner_id.name or ""

            prompt = (
                f"You are a plastic recycling materials expert.\n"
                f"A buyer match is being evaluated:\n"
                f"Polymer: {polymer}\n"
                f"Buyer: {buyer_name}\n"
                f"Match Score: {self.score or 0}%\n\n"
                f"=== RETRIEVED KNOWLEDGE BASE CONTEXT ===\n"
                f"{chunk_block}\n"
                f"=== END KB CONTEXT ===\n\n"
                f"Using ONLY the KB context above, provide:\n"
                f"1. Key technical considerations for this match\n"
                f"2. Contamination or compliance risks\n"
                f"3. Recommended talking points for the buyer\n"
                f"4. Suggested price positioning based on material specs\n"
                f"Keep it concise (under 300 words). "
                f"Be specific to the polymer and specs."
            )

            context = {
                "polymer_type": polymer,
                "match_score": self.score,
                "buyer_name": buyer_name,
            }
            result = ai_svc.generate_text(prompt, context)
            return result if result else None

        except Exception as exc:
            _logger.warning(
                "RAG AI enrichment failed (falling back): %s", exc
            )
            return None

    # ── Deterministic fallback ──────────────────────────────────────────

    def _rag_fallback_summary(self, chunks):
        """Generate deterministic summary when AI service is unavailable.

        Lists each chunk with section, score, and 200-char preview.
        """
        lines = [f"📚 KB Reference Summary ({len(chunks)} chunks retrieved):"]
        for i, c in enumerate(chunks, start=1):
            preview = (c.get("chunk_text", "")[:200] + "…"
                       if len(c.get("chunk_text", "")) > 200
                       else c.get("chunk_text", ""))
            lines.append(
                f"\n{i}. [{c.get('section', 'unknown')}] "
                f"(similarity: {c.get('score', 0):.0%})\n"
                f"   {preview}"
            )
        lines.append(
            "\n⚠️ AI service not configured — "
            "showing raw KB excerpts. Configure an AI service "
            "for synthesized insights."
        )
        return "\n".join(lines)

    # ── Batch enrichment ────────────────────────────────────────────────

    @api.model
    def action_rag_enrich_top_matches(self, intake_id, top_n=5):
        """Enrich the top N match results for an intake.

        Callable from intake form or post-match pipeline.
        """
        results = self.search(
            [("intake_id", "=", intake_id)],
            order="score desc",
            limit=top_n,
        )
        if results:
            results.action_rag_enrich()
        return results
