# -*- coding: utf-8 -*-
"""Patch A — KB Gate integration into PlasticosMatcher.

Apply after existing gates in matcher.py's ``_evaluate_gates()`` method.

HOW TO APPLY:
1. In services/matcher.py, add import at top:

    from odoo.addons.plasticos_polymer_kb.services.kb_gate import KBGate

2. In PlasticosMatcher.__init__(), add:

    self._kb_gate = None

3. In the match() method, after constructing ``gate_results`` for each
   facility but BEFORE appending to survivors, add the KB gate block
   shown below.

─────────────────────────────────────────────────────────────────────────
OPTION A: Minimal patch (paste into existing match loop)
─────────────────────────────────────────────────────────────────────────
"""

# ── PASTE THIS BLOCK into services/matcher.py ────────────────────────────
# Location: Inside the match() method, after all existing gates run
#           but BEFORE the survivor is appended to the results list.
#
# The surrounding code should look like:
#
#   gate_results = {
#       "polymer": ...,
#       "source_type": ...,
#       ...
#       "geo": ...,
#   }
#
#   # ══ KB GATE (Patch A) ════════════════════════════════════════════
#   #  << INSERT HERE >>
#   # ═════════════════════════════════════════════════════════════════
#
#   if all(v in (True, "pass", None) for v in gate_results.values()):
#       survivors.append(...)

# ── FULL DIFF-STYLE PATCH ────────────────────────────────────────────────

DIFF = """
--- a/services/matcher.py
+++ b/services/matcher.py
@@ imports (top of file)
+from odoo.addons.plasticos_polymer_kb.services.kb_gate import KBGate

@@ class PlasticosMatcher:
@@     def __init__(self, env):
         self.env = env
+        self._kb_gate = None

@@     def _get_kb_gate(self):
+        """Lazy-init KBGate; returns None if polymer_kb module not installed."""
+        if self._kb_gate is None:
+            try:
+                self._kb_gate = KBGate(self.env)
+            except Exception:
+                self._kb_gate = False  # sentinel: don't retry
+        return self._kb_gate or None

@@     def match(self, intake, facility_ids=None):
         ...
         # After all existing gates have run for each facility:
         # (gate_results dict is populated with polymer, source_type,
         #  process_type, form_equipment, contamination, moisture,
         #  volume, compliance_food, compliance_medical, geo)

+        # ══ KB GATE (polymer-specific safety rules) ══════════════════
+        kb_gate = self._get_kb_gate()
+        if kb_gate:
+            material = intake.material_profile_id
+            kb_passed, kb_reason = kb_gate.evaluate(intake, facility, material)
+            gate_results["kb_safety"] = kb_reason if not kb_passed else True
+        # ═════════════════════════════════════════════════════════════

         # Existing eligibility check continues unchanged:
         eligible = all(
             v in (True, "pass", None)
             for v in gate_results.values()
         )
         ...
"""
