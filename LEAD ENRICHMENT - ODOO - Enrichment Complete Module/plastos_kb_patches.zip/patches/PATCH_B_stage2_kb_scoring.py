# -*- coding: utf-8 -*-
"""Patch B — KB archetype scoring enrichment for Stage 2 Cypher.

Adds a ``kb_archetype_score`` dimension to the composite scoring in
``_build_stage2_query()``. This rewards facilities whose profile matches
a KB buyer archetype that fits the intake material.

HOW TO APPLY:
1. In graph_service.py, add new method ``_get_kb_enrichment_params()``
2. Modify ``_intake_to_match_params()`` to call it
3. Modify ``_build_stage2_query()`` to include KB scoring block

The enrichment is ADDITIVE — it doesn't break anything if the polymer_kb
module isn't installed (params default to empty lists, Cypher handles nulls).

─────────────────────────────────────────────────────────────────────────
"""

DIFF = """
--- a/models/graph_service.py
+++ b/models/graph_service.py

@@ Add new method to PlasticosGraphService class @@

+    def _get_kb_enrichment_params(self, material):
+        """Extract KB archetype IDs and quality tier for Stage 2 scoring.
+
+        Returns dict with:
+            kb_buyer_archetype_ids: list[str] — matching archetype IDs
+            kb_quality_tier: int — inferred quality tier (1-4, 0=unknown)
+            kb_mfi_application: str — inferred application from MFI
+            kb_safety_flags: list[str] — any safety rule IDs that apply
+        """
+        defaults = {
+            "kb_buyer_archetype_ids": [],
+            "kb_quality_tier": 0,
+            "kb_mfi_application": "",
+            "kb_safety_flags": [],
+        }
+        try:
+            from odoo.addons.plasticos_polymer_kb.services.kb_inference import (
+                KBInferenceEngine,
+            )
+        except ImportError:
+            return defaults
+
+        polymer_code = (
+            material.polymer_id.code if material.polymer_id
+            else getattr(material, "polymer", None) or ""
+        )
+        if not polymer_code:
+            return defaults
+
+        engine = KBInferenceEngine(self.env)
+
+        # Infer quality tier from contamination
+        contam_pct = (
+            getattr(material, "contamination_pct", None)
+            or getattr(material, "contamination_level", None)
+            or 0.0
+        )
+        sorting_purity = getattr(material, "sorting_purity_pct", 0.0) or 0.0
+        quality_tier = engine.infer_quality_tier(
+            polymer_code, contam_pct, sorting_purity,
+        )
+
+        # Infer MFI application
+        mfi = getattr(material, "melt_index", None) or getattr(material, "mfi", None)
+        mfi_app = engine.infer_mfi_application(polymer_code, mfi)
+
+        # Find matching buyer archetypes
+        archetypes = engine.infer_suitable_buyer_archetypes(
+            polymer_code, quality_tier, mfi=mfi,
+        )
+        archetype_ids = archetypes.mapped("buyer_id") if archetypes else []
+
+        # Safety flags
+        safety_rules = engine.get_safety_rules(polymer_code)
+        safety_flags = safety_rules.mapped("rule_id") if safety_rules else []
+
+        return {
+            "kb_buyer_archetype_ids": archetype_ids,
+            "kb_quality_tier": quality_tier,
+            "kb_mfi_application": mfi_app,
+            "kb_safety_flags": safety_flags,
+        }


@@ In _intake_to_match_params(), before the final return dict @@

+        # ── KB enrichment parameters ─────────────────────────────────
+        kb_params = self._get_kb_enrichment_params(mat)

@@ In the return dict of _intake_to_match_params() @@

+            # ── KB enrichment ────────────────────────────────────────
+            "kb_buyer_archetype_ids": kb_params.get("kb_buyer_archetype_ids", []),
+            "kb_quality_tier": kb_params.get("kb_quality_tier", 0),
+            "kb_mfi_application": kb_params.get("kb_mfi_application", ""),
+            "kb_safety_flags": kb_params.get("kb_safety_flags", []),


@@ In _build_stage2_query(), replace the COMPOSITE SCORING section @@
@@ (the WITH ... AS score block) with this enriched version @@

--- old scoring block ---
WITH f, m, distance_m, tx_count,
1.0 AS hard_score,
(form_match * 0.3 + color_match * 0.2 + source_match * 0.3 + process_match * 0.2) AS soft_score,
...

--- new scoring block (replaces the above) ---

+// ══════════════════════════════════════════════════════════════════
+// KB ARCHETYPE SCORING (Patch B)
+// Rewards facilities whose profile matches a KB buyer archetype
+// that is compatible with the intake material's inferred quality tier.
+// ══════════════════════════════════════════════════════════════════
+OPTIONAL MATCH (kbp:KBBuyerProfile)
+WHERE kbp.buyer_id IN $kb_buyer_archetype_ids
+  // Match on process type if available
+  AND (kbp.industry_segment IS NULL
+       OR f.process_type IS NULL
+       OR toLower(kbp.industry_segment) CONTAINS toLower(f.process_type))
+WITH f, m, distance_m, tx_count,
+     form_match, color_match, source_match, process_match,
+     // KB archetype match score: 0.0 if no match, up to 1.0 for strong match
+     CASE
+       WHEN $kb_quality_tier = 0 THEN 0.5  // Unknown tier — neutral
+       WHEN kbp IS NULL THEN 0.0            // No archetype match
+       ELSE
+         // Base match (0.6) + MFI window bonus (0.2) + quality tier bonus (0.2)
+         0.6
+         + CASE
+             WHEN kbp.mi_min IS NOT NULL AND kbp.mi_max IS NOT NULL
+                  AND $mfi IS NOT NULL
+                  AND $mfi >= kbp.mi_min AND $mfi <= kbp.mi_max
+             THEN 0.2 ELSE 0.0
+           END
+         + CASE
+             WHEN kbp.quality_tiers_required IS NOT NULL
+                  AND toString($kb_quality_tier) IN split(kbp.quality_tiers_required, ',')
+             THEN 0.2 ELSE 0.0
+           END
+     END AS kb_archetype_score
+
+// ══════════════════════════════════════════════════════════════════
+// COMPOSITE SCORING (enriched with KB archetype dimension)
+// Weights: w1=hard(0.40), w2=quality(0.15), w3=geo(0.20),
+//          w4=history(0.10), w5_kb=archetype(0.15)
+// w5 comes from splitting w1 (0.50 → 0.40) and w3 (0.25 → 0.20)
+// ══════════════════════════════════════════════════════════════════
+WITH f, m, distance_m, tx_count, kb_archetype_score,
+     1.0 AS hard_score,
+     (form_match * 0.3 + color_match * 0.2
+      + source_match * 0.3 + process_match * 0.2) AS soft_score,
+     CASE
+       WHEN $radius_meters > 0 AND distance_m > 0
+       THEN toFloat(max(0, 1.0 - (distance_m / $radius_meters)))
+       WHEN distance_m = 0 AND ($lat IS NULL OR $lon IS NULL)
+       THEN 0.0  // ← FIX: missing coords = neutral, not 1.0
+       ELSE 0.0
+     END AS geo_score
+
+WITH f, m, distance_m, tx_count,
+     hard_score, soft_score, geo_score, kb_archetype_score,
+     // Enriched composite with 5 dimensions
+     (0.40 * hard_score
+      + $w2 * soft_score
+      + 0.20 * geo_score
+      + $w4 * CASE WHEN tx_count > 0
+              THEN toFloat(log(1 + tx_count)) / toFloat(log(1 + 100))
+              ELSE 0.0 END
+      + 0.15 * COALESCE(kb_archetype_score, 0.0)
+     ) AS score
+
+ORDER BY score DESC
+LIMIT $max_results
+
+RETURN f.facility_id AS facility_partner_id,
+       f.name AS facility_name,
+       f.process_type AS process_type,
+       m.polymer AS polymer,
+       m.form AS form,
+       m.color AS color,
+       round(score * 100) / 100.0 AS score,
+       round(distance_m / 1609.34) AS distance_miles,
+       tx_count,
+       hard_score,
+       soft_score,
+       geo_score,
+       kb_archetype_score
"""
