# -*- coding: utf-8 -*-
"""Patch C — Neo4j schema constraints for KB nodes.

Add to initialize_schema() in graph_service.py:
"""

CONSTRAINTS_TO_ADD = """
--- a/models/graph_service.py  (initialize_schema method)
+++ b/models/graph_service.py

@@ In initialize_schema(), add to the constraints list @@

     constraints = [
         "CREATE CONSTRAINT facility_id IF NOT EXISTS ...",
         "CREATE CONSTRAINT material_id IF NOT EXISTS ...",
+        # ── KB constraints (Patch C) ──────────────────────────────
+        "CREATE CONSTRAINT polymer_kb_type IF NOT EXISTS "
+        "FOR (kb:PolymerKB) REQUIRE kb.polymer_type IS UNIQUE",
+        "CREATE CONSTRAINT kb_grade_id IF NOT EXISTS "
+        "FOR (g:KBGrade) REQUIRE g.grade_id IS UNIQUE",
+        "CREATE CONSTRAINT kb_buyer_profile_id IF NOT EXISTS "
+        "FOR (bp:KBBuyerProfile) REQUIRE bp.buyer_id IS UNIQUE",
     ]
"""
